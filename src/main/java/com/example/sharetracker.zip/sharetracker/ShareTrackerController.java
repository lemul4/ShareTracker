package com.example.sharetracker;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import ru.tinkoff.piapi.contract.v1.*;
import ru.tinkoff.piapi.core.InvestApi;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ShareTrackerController {
    @FXML
    private TextField searchField;

    @FXML
    private TableView<ShareInfo> sharesTable;

    @FXML
    private TableColumn<ShareInfo, Boolean> bookmarkColumn;

    private final List<String> savedFigi = new ArrayList<>();

    public static double minuteCandle(InvestApi api, String figi) {
        var candles1min = api.getMarketDataService()
                .getCandlesSync(figi, Instant.now().minus(1, ChronoUnit.DAYS), Instant.now(),
                        CandleInterval.CANDLE_INTERVAL_1_MIN);
        double openValue = 0;
        for (HistoricCandle candle : candles1min) {
            openValue = candle.getClose().getUnits() + candle.getClose().getNano() / 1_000_000_000.0;
        }
        return openValue;
    }

    @FXML
    public void initialize() {
        // Устанавливаем свойства значений в столбце "Bookmark"
        bookmarkColumn.setCellValueFactory(new PropertyValueFactory<>("bookmarked"));
        bookmarkColumn.setCellFactory(column -> new TableCell<>() {
            private final CheckBox checkBox = new CheckBox();

            {
                checkBox.setOnAction(event -> {
                    ShareInfo shareInfo = getTableView().getItems().get(getIndex());
                    if (checkBox.isSelected()) {
                        savedFigi.add(shareInfo.getFigi());
                    } else {
                        savedFigi.remove(shareInfo.getFigi());
                    }
                });
            }

            @Override
            protected void updateItem(Boolean item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    checkBox.setSelected(item);
                    setGraphic(checkBox);
                }
            }
        });
    }

    @FXML
    public void searchShares() {
        String token = "t._UnQBPxxIB6HBnGkSZFQ18jMkKW5s_WVuljeHMpcDUM_qni-EmvBsvXb1P398tJTs-F2meWyuCBUdcfVfvXoaQ";
        var api = InvestApi.createReadonly(token);
        String name = searchField.getText();

        // Очистка таблицы перед новым поиском
        sharesTable.getItems().clear();

        shereData(api, name);
        // Добавим setCellValueFactory для каждого столбца
        setCellValueColumn();
    }

    private void setCellValueColumn() {
        TableColumn<ShareInfo, String> figiColumn = (TableColumn<ShareInfo, String>) sharesTable.getColumns().get(0);
        TableColumn<ShareInfo, String> nameColumn = (TableColumn<ShareInfo, String>) sharesTable.getColumns().get(1);
        TableColumn<ShareInfo, String> tickerColumn = (TableColumn<ShareInfo, String>) sharesTable.getColumns().get(2);
        TableColumn<ShareInfo, Double> costColumn = (TableColumn<ShareInfo, Double>) sharesTable.getColumns().get(3);

        figiColumn.setCellValueFactory(new PropertyValueFactory<>("figi"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        tickerColumn.setCellValueFactory(new PropertyValueFactory<>("ticker"));
        costColumn.setCellValueFactory(new PropertyValueFactory<>("cost"));

        for (ShareInfo shareInfo : sharesTable.getItems()) {
            // Добавляем слушатель для изменений в закладках
            shareInfo.bookmarkedProperty().addListener((observable, oldValue, newValue) -> {
                if (newValue) {
                    savedFigi.add(shareInfo.getFigi());
                } else {
                    savedFigi.remove(shareInfo.getFigi());
                }
            });
        }
    }

    @FXML
    public void viewBookmarks() {
        String token = "t._UnQBPxxIB6HBnGkSZFQ18jMkKW5s_WVuljeHMpcDUM_qni-EmvBsvXb1P398tJTs-F2meWyuCBUdcfVfvXoaQ";
        var api = InvestApi.createReadonly(token);

        // Очистка таблицы перед новым отображением закладок
        sharesTable.getItems().clear();

        for (String figi : savedFigi) {
            shereData(api, figi);
        }
        // Добавим setCellValueFactory для каждого столбца
        setCellValueColumn();
    }

    private void shereData(InvestApi api, String figi) {
        List<InstrumentShort> instruments = api.getInstrumentsService().findInstrumentSync(figi);
        for (InstrumentShort instrument : instruments) {
            String fi = instrument.getFigi();
            if (Objects.equals(String.valueOf(instrument.getInstrumentKind()), "INSTRUMENT_TYPE_SHARE") && (minuteCandle(api, instrument.getFigi()) != 0) && (!fi.startsWith("TC"))) {
                String shareFigi = instrument.getFigi();
                String shareName = instrument.getName();
                String shareTicker = instrument.getTicker();
                double shareCost = minuteCandle(api, instrument.getFigi());
                ShareInfo shareInfo = new ShareInfo(shareFigi, shareName, shareTicker, shareCost);
                shareInfo.setBookmarked(savedFigi.contains(shareFigi));
                sharesTable.getItems().add(shareInfo);
            }
        }
    }
}
